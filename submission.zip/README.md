# Fixed Beta(1,1) shrinkage comparison

An untrained, standard-library-only comparison candidate for PAIEC.
For matching subject/benchmark labels, predict (successes + 1)/(count + 2).
Return 0.5 at budget zero or with no matching evidence. Match the complete
subject dictionary and anonymous benchmark_id; never retain state across calls.
The prior was fixed before seeing competition outcomes, not tuned on test labels.
No labeling.py: use the evaluator's default random acquisition.

This follows the interface and grouping convention of the official empirical
mean baseline at aims-foundations/paiec_baseline commit
82d330ddcdb16016a3ae9e048db7e588ba2c6a39. It is a comparison hypothesis, not a
proven improvement. Current hosted interface compatibility requires a real
accepted evaluation; local checks do not establish it. No competition dataset,
credentials or external API dependencies are included.
